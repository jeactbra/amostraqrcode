
#!/usr/bin/env python3
"""
QR Label Generator for Lab Samples (Biochar & Biomass) — with Dates

- Tipos de rótulo:
  * biochar: sample_name, producer, biomass, reactor_type, pyro_temp_C, residence_time_min, production_date, notes
  * biomass: biomass_name, origin, collection_date, notes
- Modos:
  * Interativo (sem args): pergunta no terminal e gera etiquetas
  * Único (CLI): --kind biochar|biomass com flags
  * Lote (CSV): --csv labels.csv (linhas podem misturar kinds)
- Payload inclui: kind, uuid (v4), schema=arrakis.lab.qrlabel.v2, timestamp ISO

Layout do rótulo:
  Título na parte superior: "esquerda | direita" (ex.: "AW-BC500-01 | Agave Wercklei")
  QR code centralizado embaixo.

CSV (cabeçalho sugerido, agora com datas):
kind,sample_name,producer,biomass,reactor_type,pyro_temp_C,residence_time_min,production_date,biomass_name,origin,collection_date,notes

Datas aceitas (interativo):
  - ISO: YYYY-MM-DD (recomendado)
  - BR:  DD/MM/YYYY  (será convertido para ISO)
  - vazio: salva como string vazia

Dependências
  pip install pillow qrcode
"""
import argparse
import json
import uuid
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import qrcode
import csv
import datetime as dt
import sys
import textwrap
import re

SCHEMA = "arrakis.lab.qrlabel.v2"

# ---------- Font helper ----------
def _load_font(size=36):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/Library/Fonts/Arial Unicode.ttf",
        "/Library/Fonts/Arial Bold.ttf",
        "C:\\Windows\\Fonts\\arialbd.ttf",
        "C:\\Windows\\Fonts\\arial.ttf",
    ]
    for p in candidates:
        path = Path(p)
        if path.exists():
            try:
                return ImageFont.truetype(str(path), size=size)
            except Exception:
                continue
    return ImageFont.load_default()

# ---------- Date normalization ----------
def _normalize_date(s: str) -> str:
    """
    Converte 'DD/MM/YYYY' -> 'YYYY-MM-DD'.
    Mantém 'YYYY-MM-DD' se já estiver OK.
    Retorna '' se entrada vazia.
    Sem validação de calendário profunda (formatos básicos).
    """
    s = (s or "").strip()
    if not s:
        return ""
    # ISO direto
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return s
    # BR DD/MM/YYYY
    m = re.fullmatch(r"(\d{2})/(\d{2})/(\d{4})", s)
    if m:
        dd, mm, yyyy = m.groups()
        return f"{yyyy}-{mm}-{dd}"
    # Tenta ser tolerante com DD-MM-YYYY
    m = re.fullmatch(r"(\d{2})-(\d{2})-(\d{4})", s)
    if m:
        dd, mm, yyyy = m.groups()
        return f"{yyyy}-{mm}-{dd}"
    # Último caso: retorna original (não explode)
    return s

# ---------- Payload builders ----------
def make_payload_biochar(sample_name, producer, biomass, reactor_type, pyro_temp_c,
                         residence_time_min, production_date=None, notes=None):
    return json.dumps({
        "kind": "biochar",
        "uuid": str(uuid.uuid4()),
        "schema": SCHEMA,
        "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
        "sample_name": sample_name,
        "producer": producer,
        "biomass": biomass,
        "reactor_type": reactor_type,
        "pyro_temp_C": pyro_temp_c,
        "residence_time_min": residence_time_min,
        "production_date": _normalize_date(production_date or ""),
        "notes": (notes or "")
    }, ensure_ascii=False)

def make_payload_biomass(biomass_name, origin, collection_date=None, notes=None):
    return json.dumps({
        "kind": "biomass",
        "uuid": str(uuid.uuid4()),
        "schema": SCHEMA,
        "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
        "biomass_name": biomass_name,
        "origin": origin,
        "collection_date": _normalize_date(collection_date or ""),
        "notes": (notes or "")
    }, ensure_ascii=False)

# ---------- Rendering ----------
def render_label_png(title_left, title_right, qr_payload, outpath, label_width_px=800, qr_box_size=10, border=4):
    # Build QR
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=qr_box_size,
        border=border
    )
    qr.add_data(qr_payload)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white").convert("RGB")

    # Canvas + text
    font_title = _load_font(size=44)
    padding = 30
    line_gap = 8

    title_text = f"{title_left} | {title_right}" if title_right else f"{title_left}"
    dummy = Image.new("RGB", (label_width_px, 100), "white")
    draw_dummy = ImageDraw.Draw(dummy)
    text_w, _ = draw_dummy.textbbox((0,0), title_text, font=font_title)[2:]
    if text_w > label_width_px - 2*padding:
        est_chars = max(18, int(len(title_text) * (label_width_px - 2*padding) / text_w))
        wrapped = textwrap.fill(title_text, width=est_chars)
        title_lines = wrapped.splitlines()
    else:
        title_lines = [title_text]

    tmp = Image.new("RGB", (label_width_px, 200), "white")
    dtmp = ImageDraw.Draw(tmp)
    heights = []
    for line in title_lines:
        bbox = dtmp.textbbox((0,0), line, font=font_title)
        heights.append(bbox[3]-bbox[1])
    title_h = sum(heights) + line_gap*(len(heights)-1)

    qr_scale = min((label_width_px - 2*padding) / qr_img.width, 1.0)
    new_w = int(qr_img.width * qr_scale)
    new_h = int(qr_img.height * qr_scale)
    try:
        from PIL.Image import Resampling
        qr_img_resized = qr_img.resize((new_w, new_h), Resampling.NEAREST)
    except Exception:
        qr_img_resized = qr_img.resize((new_w, new_h))

    total_h = padding + title_h + padding + new_h + padding
    canvas = Image.new("RGB", (label_width_px, total_h), "white")
    draw = ImageDraw.Draw(canvas)

    y = padding
    for i, line in enumerate(title_lines):
        bbox = draw.textbbox((0,0), line, font=font_title)
        lw = bbox[2]-bbox[0]
        lh = bbox[3]-bbox[1]
        x = (label_width_px - lw)//2
        draw.text((x, y), line, fill="black", font=font_title)
        y += lh + (line_gap if i < len(title_lines)-1 else 0)

    qr_x = (label_width_px - new_w)//2
    qr_y = y + padding
    canvas.paste(qr_img_resized, (qr_x, qr_y))

    outpath = Path(outpath)
    outpath.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(outpath, format="PNG")
    return outpath

# ---------- CSV ----------
def process_csv(args):
    outdir = Path(args.outdir or "out_batch")
    outdir.mkdir(parents=True, exist_ok=True)
    with open(args.csv, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        line = 1
        for row in reader:
            line += 1
            kind = (row.get("kind","") or "biochar").strip().lower()
            try:
                if kind == "biomass":
                    biomass_name = (row.get("biomass_name","") or "").strip()
                    origin = (row.get("origin","") or "").strip()
                    collection_date = _normalize_date((row.get("collection_date","") or "").strip())
                    notes = (row.get("notes","") or "").strip()
                    if not biomass_name or not origin:
                        print(f"[WARN] line {line}: biomass_name and origin are required for biomass. Skipping.")
                        continue
                    payload = make_payload_biomass(biomass_name, origin, collection_date, notes)
                    fname = f"{biomass_name}_label.png".replace(" ", "_")
                    outpath = outdir / fname
                    render_label_png(_titlecase(biomass_name), _titlecase(origin), payload, outpath,
                                     label_width_px=args.label_width_px,
                                     qr_box_size=args.qr_box_size,
                                     border=args.qr_border)
                    print(f"✔ biomass: {biomass_name} -> {outpath}")
                else:
                    sample_name = (row.get("sample_name","") or "").strip()
                    if not sample_name:
                        print(f"[WARN] line {line}: missing sample_name for biochar. Skipping.")
                        continue
                    producer = (row.get("producer","") or "").strip()
                    biomass = (row.get("biomass","") or "").strip()
                    reactor_type = (row.get("reactor_type","") or "").strip()
                    pyro_temp_c = float((row.get("pyro_temp_C","") or "0").replace(",", "."))
                    residence_time_min = float((row.get("residence_time_min","") or "0").replace(",", "."))
                    production_date = _normalize_date((row.get("production_date","") or "").strip())
                    notes = (row.get("notes","") or "").strip()

                    payload = make_payload_biochar(sample_name, producer, biomass, reactor_type,
                                                   pyro_temp_c, residence_time_min, production_date, notes)

                    fname = f"{sample_name}_label.png".replace(" ", "_")
                    outpath = outdir / fname
                    render_label_png(_titlecase(sample_name), _titlecase(biomass), payload, outpath,
                                     label_width_px=args.label_width_px,
                                     qr_box_size=args.qr_box_size,
                                     border=args.qr_border)
                    print(f"✔ biochar: {sample_name} -> {outpath}")
            except Exception as e:
                print(f"[WARN] line {line}: {e}")

# ---------- Helpers de input ----------
def _prompt_float(msg, default=None):
    while True:
        s = input(msg).strip()
        if not s and default is not None:
            return default
        try:
            return float(s.replace(",", "."))
        except ValueError:
            print("Valor inválido. Use número (ponto ou vírgula decimal).")

def _titlecase(s: str) -> str:
    """Capitaliza a primeira letra de cada palavra, preservando siglas (heurística simples)."""
    if not s:
        return s
    parts = s.split()
    out = []
    for p in parts:
        if len(p) <= 3 and p.isupper():
            out.append(p)  # provável sigla
        else:
            out.append(p[:1].upper() + p[1:].lower())
    return " ".join(out)

def _prompt_str(msg, default=None, required=False, capitalize_first=False):
    while True:
        s = input(msg).strip()
        if s:
            if capitalize_first:
                s = _titlecase(s)
            return s
        if default is not None:
            return default
        if not required:
            return ""
        print("Campo obrigatório.")

# ---------- Interativo ----------
def process_interactive():
    print("\n=== QR Label Generator (Interativo) ===")
    print("Escolha o tipo: [1] biochar  [2] biomassa")
    kind_sel = input("Tipo (1/2): ").strip()
    if kind_sel == "2":
        # Biomassa
        outdir = Path("out_interactive_biomass")
        outdir.mkdir(parents=True, exist_ok=True)
        last = {}
        while True:
            biomass_name    = _prompt_str(f"Nome da biomassa [{last.get('biomass_name','')}]     : ", default=last.get("biomass_name"), required=True, capitalize_first=True)
            origin          = _prompt_str(f"Origem [{last.get('origin','')}]                     : ", default=last.get("origin"), required=True, capitalize_first=True)
            collection_date = _prompt_str(f"Data de coleta (YYYY-MM-DD ou DD/MM/YYYY) [{last.get('collection_date','')}] : ", default=last.get("collection_date",""), capitalize_first=False)
            notes           = _prompt_str(f"Notas (opcional) [{last.get('notes','')}]            : ", default=last.get("notes",""), capitalize_first=False)

            last.update({"biomass_name": biomass_name, "origin": origin, "collection_date": collection_date, "notes": notes})

            payload = make_payload_biomass(biomass_name, origin, collection_date, notes)
            outpath = outdir / f"{biomass_name}_label.png".replace(" ", "_")
            render_label_png(biomass_name, origin, payload, outpath)
            print(f"✔ Gerado (biomassa): {outpath.resolve()}\n")
            again = input("Gerar outra etiqueta de biomassa? [S/N]: ").strip().lower()
            if not again or again.startswith("n"):
                break
    else:
        # Biochar (default)
        outdir = Path("out_interactive_biochar")
        outdir.mkdir(parents=True, exist_ok=True)
        last = {}
        while True:
            sample_name     = _prompt_str(f"Nome da amostra [{last.get('sample_name','')}]      : ", default=last.get("sample_name"), required=True, capitalize_first=True)
            biomass         = _prompt_str(f"Biomassa [{last.get('biomass','')}]                 : ", default=last.get("biomass"), required=True, capitalize_first=True)
            producer        = _prompt_str(f"Quem produziu [{last.get('producer','')}]           : ", default=last.get("producer"), required=True, capitalize_first=True)
            reactor         = _prompt_str(f"Tipo de reator [{last.get('reactor','')}]           : ", default=last.get("reactor"), required=True, capitalize_first=True)
            pyroC           = _prompt_float(f"Temperatura de pirólise °C [{last.get('pyroC','')}] : ", default=last.get("pyroC", None))
            res_min         = _prompt_float(f"Tempo de residência (min) [{last.get('res_min','')}] : ", default=last.get("res_min", None))
            production_date = _prompt_str(f"Data de produção (YYYY-MM-DD ou DD/MM/YYYY) [{last.get('production_date','')}] : ", default=last.get("production_date",""), capitalize_first=False)
            notes           = _prompt_str(f"Notas (opcional) [{last.get('notes','')}]           : ", default=last.get("notes",""), capitalize_first=False)

            last.update({
                "sample_name": sample_name,
                "biomass": biomass,
                "producer": producer,
                "reactor": reactor,
                "pyroC": pyroC,
                "res_min": res_min,
                "production_date": production_date,
                "notes": notes
            })

            payload = make_payload_biochar(sample_name, producer, biomass, reactor, pyroC, res_min, production_date, notes)
            outpath = outdir / f"{sample_name}_label.png".replace(" ", "_")
            render_label_png(sample_name, biomass, payload, outpath)
            print(f"✔ Gerado (biochar): {outpath.resolve()}\n")
            again = input("Gerar outra etiqueta de biochar? [S/N]: ").strip().lower()
            if not again or again.startswith("n"):
                break

# ---------- Único ----------
def process_single(args):
    outdir = Path(args.outdir or "out_single")
    outdir.mkdir(parents=True, exist_ok=True)

    if args.kind == "biomass":
        if not args.biomass_name or not args.origin:
            print("Error: --biomass-name and --origin are required for --kind biomass", file=sys.stderr)
            sys.exit(2)
        payload = make_payload_biomass(args.biomass_name, args.origin, args.collection_date, args.notes)
        fname = f"{args.biomass_name}_label.png".replace(" ", "_")
        outpath = outdir / fname
        render_label_png(_titlecase(args.biomass_name), _titlecase(args.origin), payload, outpath,
                         label_width_px=args.label_width_px,
                         qr_box_size=args.qr_box_size,
                         border=args.qr_border)
        print(f"✔ Biomass label -> {outpath}")
    else:
        required = ["producer", "biomass", "reactor_type", "pyro_temp_c", "residence_time_min", "sample_name"]
        missing = [k for k in required if getattr(args, k) in (None, "")]
        if missing:
            print(f"Error: missing required fields for biochar: {', '.join(missing)}", file=sys.stderr)
            sys.exit(2)
        payload = make_payload_biochar(
            sample_name=args.sample_name,
            producer=args.producer,
            biomass=args.biomass,
            reactor_type=args.reactor_type,
            pyro_temp_c=args.pyro_temp_c,
            residence_time_min=args.residence_time_min,
            production_date=args.production_date,
            notes=args.notes
        )
        fname = f"{args.sample_name}_label.png".replace(" ", "_")
        outpath = outdir / fname
        render_label_png(_titlecase(args.sample_name), _titlecase(args.biomass), payload, outpath,
                         label_width_px=args.label_width_px,
                         qr_box_size=args.qr_box_size,
                         border=args.qr_border)
        print(f"✔ Biochar label -> {outpath}")

# ---------- Args ----------
def parse_args():
    p = argparse.ArgumentParser(description="Generate QR code labels for lab samples (biochar & biomass).")
    group = p.add_mutually_exclusive_group(required=False)
    group.add_argument("--csv", type=str, help="Path to CSV file with samples.")
    group.add_argument("--sample-name", type=str, help="Single label: sample name (biochar).")
    # Common options
    p.add_argument("--kind", type=str, default="biochar", choices=["biochar","biomass"], help="Label kind.")
    # Biochar
    p.add_argument("--producer", type=str, help="Who produced the sample (biochar).")
    p.add_argument("--biomass", type=str, help="Biomass used (biochar).")
    p.add_argument("--reactor-type", type=str, help="Reactor type (biochar).")
    p.add_argument("--pyro-temp-c", type=float, help="Pyrolysis temperature in °C (biochar).")
    p.add_argument("--residence-time-min", type=float, help="Residence time (min) (biochar).")
    p.add_argument("--production-date", type=str, help="Production date YYYY-MM-DD (biochar).")
    # Biomass
    p.add_argument("--biomass-name", type=str, help="Biomass name (biomass).")
    p.add_argument("--origin", type=str, help="Origin (biomass).")
    p.add_argument("--collection-date", type=str, help="Collection date YYYY-MM-DD (biomass).")
    # Common
    p.add_argument("--notes", type=str, default="", help="Optional notes.")
    p.add_argument("--outdir", type=str, default=None, help="Output directory.")
    p.add_argument("--label-width-px", type=int, default=800, help="Canvas width in pixels (PNG).")
    p.add_argument("--qr-box-size", type=int, default=10, help="QR module size (bigger -> larger QR).")
    p.add_argument("--qr-border", type=int, default=4, help="QR border modules.")
    return p.parse_args()

def main():
    args = parse_args()
    # Interativo: sem CSV e sem sample_name (biochar) -> prompt
    if not args.csv and not args.sample_name and (args.kind == "biochar") and not args.production_date:
        process_interactive()
        return
    # Interativo também para biomassa sem args
    if not args.csv and args.kind == "biomass" and not args.biomass_name and not args.collection_date:
        process_interactive()
        return

    if args.csv:
        process_csv(args)
    else:
        # Normaliza datas passadas por CLI
        if args.production_date:
            args.production_date = _normalize_date(args.production_date)
        if args.collection_date:
            args.collection_date = _normalize_date(args.collection_date)
        process_single(args)

if __name__ == "__main__":
    main()
